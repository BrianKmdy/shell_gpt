from .app import main as main
from .app import entry_point as cli  # noqa: F401
